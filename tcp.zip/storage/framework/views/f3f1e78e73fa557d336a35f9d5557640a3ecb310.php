<?php $__env->startSection("meta_tags"); ?>
<title><?php echo e(__("City List")); ?></title>
    <meta name="description" content="City List and Manage City Details">
    <meta name="keywords" content="City,City">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header border-0">
        <?php echo e(__('City List')); ?>

    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(__('ID')); ?>

                        </th>
                        <th>
                            <?php echo e(__('City')); ?>

                        </th>
                        <th>
                            <?php echo e(__('County')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($city->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($city->id ?? ''); ?>

                            </td>

                            <td>
                                <?php echo e($city->city ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($city->county ?? ''); ?>

                            </td>

                            <td>
                                
                                <a class="btn btn-sm btn-info mb-2" href="<?php echo e(route('admin.cities.edit', $city->id)); ?>">
                                    <?php echo e(__('Edit')); ?>

                                </a>
                                
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo e($cities->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('core::layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\resources\views/admin/cities/index.blade.php ENDPATH**/ ?>