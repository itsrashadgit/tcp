<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<script>

    toastr.options =
    {
        "closeButton" : true,
        "progressBar" : true
    }

    <?php if(Session::has('success')): ?>
            toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>

    <?php if(Session::has('info')): ?>
        toastr.info("<?php echo e(session('info')); ?>");
    <?php endif; ?>

    <?php if(Session::has('warning')): ?>
        toastr.warning("<?php echo e(session('warning')); ?>");
    <?php endif; ?>

</script>
<?php /**PATH C:\xampp\htdocs\tcp\packages\salim-hosen\Core\src\Providers/../../resources/views/partials/toastr.blade.php ENDPATH**/ ?>