<?php $__env->startSection("meta_tags"); ?>
<title><?php echo e(__("State List")); ?></title>
    <meta name="description" content="State List and Manage State Details">
    <meta name="keywords" content="State,State">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header border-0">
        <?php echo e(__('State List')); ?>

    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(__('Serial')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Name')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Code')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Image')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($state->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($loop->index + 1); ?>

                            </td>
                            <td>
                                <?php echo e($state->name ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($state->code ?? ''); ?>

                            </td>
                            <td>
                                <img src="<?php echo e(asset("uploads/images/$state->image")); ?>" alt="" width="60">
                            </td>
                            <td>
                                <a class="btn btn-sm btn-primary mb-2" href="<?php echo e(route('admin.counties.index', ["state" => $state->id])); ?>">
                                    <?php echo e(__('Counties')); ?>

                                </a>
                                <a class="btn btn-sm btn-info mb-2" href="<?php echo e(route('admin.states.edit', $state->id)); ?>">
                                    <?php echo e(__('Edit')); ?>

                                </a>
                                
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('core::layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\resources\views/admin/states/index.blade.php ENDPATH**/ ?>