 <!-- Shipping Methods Modal -->
 <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="exampleModalLabel"
 aria-hidden="true">
 <div class="modal-dialog">
     <div class="modal-content">
         <div class="modal-header">
             <h5 class="modal-title ember-bold" id="exampleModalLabel"><?php echo e(__('Login')); ?>

             </h5>
             <button type="button" class="btn-close" data-bs-dismiss="modal"
                 aria-label="Close"></button>
         </div>
         <div class="modal-body">
             <div class="p-2">
                 <form action="<?php echo e(route('login')); ?>" method="post" @submit.prevent="submitLoginForm">

                     <div class="mb-3">
                        <input class="form-control form-round" type="email" name="email" id="email"
                                :class="{ 'is-invalid': errors.email }" v-model="loginform.email" autocomplete="new-password" placeholder="Email">
                        <div class="invalid-feedback">{{ errors.email }}</div>
                     </div>

                     <div class="mb-3">
                        <input class="form-control form-round" type="password" name="password" id="password"
                            autocomplete="new-password" :class="{ 'is-invalid': errors.password }"
                            v-model="loginform.password" autocomplete="new-password" placeholder="Password">
                        <div class="invalid-feedback">{{ errors.password }}</div>
                     </div>

                     <div class="mb-2 d-flex justify-content-between">
                         <label>
                             <input type="checkbox" name="remember" v-model="loginform.remember" id="remember">
                             <span class="text-muted"><?php echo e(__("Remember Me")); ?></span>
                         </label>
                         <a href="<?php echo e(route('password.request')); ?>"
                                class="text-muted"><?php echo e(__('Forgot Password?')); ?></a>
                     </div>

                     <div class="text text-danger mb-3" v-show="errors.message">{{ errors.message }} <a
                        href="<?php echo e(route('verification.resend')); ?>"
                        v-show="errors.verification"><?php echo e(__('Resend Verification Link')); ?></a></div>

                     <div class="mb-5">
                        <div class="mb-3 d-flex justify-content-between">
                            <button type="submit" class="btn btn-primary w-100" :disabled="loading">
                                <i class="fas fa-spinner fa-spin" v-show="loading"></i>
                                <span><?php echo e(__('Login')); ?></span>
                            </button>
                        </div>
                     </div>
                 </form>

             </div>
             <div class="text-center mb-3">
                 <p class="text-muted mb-0"><?php echo e(__('Dont have an account')); ?>?</p>
                 <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
             </div>
         </div>
     </div>
 </div>
</div>


<?php $__env->startPush("body_scripts"); ?>
<script>
    vdata = {
        ...vdata,
        loginform: {
            email: '',
            password: '',
            role: "user"
        },
        errors: {},
        loading: false,
        response: null
    }

    vmethods = {
        ...vmethods,
        async submitLoginForm() {

            try {

                this.loading = true;
                this.errors = {};
                this.response = "";
                const res = await axios.post("<?php echo e(route('login')); ?>", this.loginform);
                window.location.reload();

            } catch (e) {

                if (e.response && e.response.status == 422) {
                    for (const [key, value] of Object.entries(e.response.data.errors)) {
                        this.errors[key] = value[0];
                    }
                } else {
                    toastr.error("Something Wen't Wrong!");
                }

                this.loading = false;

            }

        }
    }

    vcreated = {
        ...vcreated
        // function key: function(){}
    }

    vmounted = {
        ...vmounted,
        // function key: function(){}
    }
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\tcp\resources\views/partials/login-modal.blade.php ENDPATH**/ ?>