<?php $__env->startSection("meta_tags"); ?>
<title><?php echo e(__("Page List")); ?></title>
    <meta name="description" content="Page LIst and Manage Page Details">
    <meta name="keywords" content="page,page_list">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('pages.create')); ?>">
                <?php echo e(__("Create Page")); ?>

            </a>
        </div>
    </div>

<div class="card">
    <div class="card-header border-0">
        <?php echo e(__("Page List")); ?>

    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(__("#")); ?>

                        </th>
                        <th>
                            <?php echo e(__("Name")); ?>

                        </th>
                        <th>
                            <?php echo e(__("URL")); ?>

                        </th>
                        <th>
                            <?php echo e(__("Status")); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($page->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($page->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($page->name ?? ''); ?>

                            </td>
                            <td>
                                /<?php echo e($page->url ?? ''); ?>

                            </td>
                            <td>
                                <?php if($page->is_active): ?>
                                    <span class="badge bg-primary"><?php echo e(__("Active")); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-dark"><?php echo e(__("Inactive")); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                

                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('pages.edit', ['page' => $page['id'], 'locale' => app()->getLocale()])); ?>">
                                        <?php echo e(__("Edit")); ?>

                                    </a>

                                     

                                    <?php if($page->customization_route): ?>
                                        <?php if(Route::has($page->customization_route)): ?>
                                            <a class="btn btn-xs btn-info" target="_blank" href="<?php echo e(route($page->customization_route)); ?>">
                                                <?php echo e(__("Customize")); ?>

                                            </a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($page->url): ?>
                                            <?php if (isset($component)) { $__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff = $component; } ?>
<?php $component = SalimHosen\Core\View\Components\DeleteDialog::resolve(['id' => $page['id'],'action' => route('pages.destroy', $page['id'])] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('core-delete-dialog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(SalimHosen\Core\View\Components\DeleteDialog::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff)): ?>
<?php $component = $__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff; ?>
<?php unset($__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff); ?>
<?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('core::layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\packages\salim-hosen\Website\src\Providers/../../resources/views/page/index.blade.php ENDPATH**/ ?>