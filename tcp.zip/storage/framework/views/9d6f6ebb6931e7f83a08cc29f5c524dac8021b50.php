


<?php $__env->startSection('meta_tags'); ?>
    <title><?php echo e(__('Home - Buyer')); ?></title>
    <meta name="description" content="Create Employee and Manage Employee Details">
    <meta name="keywords" content="employee,employee_create">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="tophive-container">

        <?php echo $__env->make('partials.profile-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="tophive-grid">
            <main id="main" class="content-area tophive-col-12">
                <div class="content-inner">
                    <article id="post-0"
                        class="bp_members type-bp_members entry post-0 page type-page status-publish hentry pmpro-no-access">
                        <header class="entry-header">
                            <h1 class="entry-title"><?php echo e($user->name); ?></h1>
                        </header>
                        <!-- .entry-header -->

                        <div class="entry-content">
                            <div id="buddypress" class="buddypress-wrap metafans round-avatars bp-dir-hori-nav">

                                <div class="bp-wrap">
                                    <div id="item-body" class="item-body">

                                        <?php if(Auth::user()->id == $user->id): ?>
                                            <nav class="bp-navs no-ajax user-subnav" id="subnav" role="navigation"
                                                aria-label="Profile menu">
                                                <ul class="subnav">
                                                    <li id="public-personal-li" class="bp-personal-sub-tab">
                                                        <a href="<?php echo e(route('user.profile', $user->username)); ?>" id="public">
                                                            View
                                                        </a>
                                                    </li>

                                                    <li id="edit-personal-li" class="bp-personal-sub-tab current selected">
                                                        <a href="<?php echo e(route('profile.edit')); ?>" id="edit">
                                                            Edit
                                                        </a>
                                                    </li>

                                                    
                                                </ul>
                                            </nav>
                                        <?php endif; ?>
                                        <!-- .item-list-tabs -->

                                        <div class="profile edit">


                                            <h2 class="screen-heading edit-profile-screen">Edit Profile</h2>


                                            <form action="<?php echo e(route('api.profile.update')); ?>" method="post" @submit.prevent="submitForm">

                                                <?php echo csrf_field(); ?>

                                                

                                                <div class="mb-3" v-if=" form.user_type == 'tradesmen' || form.user_type == 'contractors' ">
                                                    <label class="required" for="trade"><?php echo e(__('Trade')); ?></label>
                                                        <select name="trade" id="trade" class="form-control">
                                                            <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($trade->id); ?>"><?php echo e($trade->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    <div class="invalid-feedback">{{ errors.trade }}</div>
                                                </div>

                                                <div class="mb-3" v-if="form.user_type == 'tradesmen'">
                                                    <label class="" for="profession_title"><?php echo e(__('Profession Title')); ?></label>
                                                    <input class="form-control form-round" type="text" name="profession_title" id="profession_title"
                                                        :class="{ 'is-invalid': errors.profession_title }" v-model="form.profession_title">
                                                    <div class="invalid-feedback">{{ errors.profession_title }}</div>
                                                </div>

                                                <div class="mb-3">
                                                    <label class="required" for="name"><?php echo e(__('Name')); ?></label>
                                                    <input class="form-control form-round" type="text" name="name" id="name"
                                                        :class="{ 'is-invalid': errors.name }" v-model="form.name">
                                                    <div class="invalid-feedback">{{ errors.name }}</div>
                                                </div>

                                                <div class="mb-3">
                                                    <label class="required" for="email"><?php echo e(__('Email')); ?></label>
                                                    <input class="form-control form-round" type="email" name="email" id="email"
                                                        :class="{ 'is-invalid': errors.email }" v-model="form.email">
                                                    <div class="invalid-feedback">{{ errors.email }}</div>
                                                </div>

                                                <div class="mb-3">
                                                    <label class="required" for="phone"><?php echo e(__('Phone')); ?></label>
                                                    <input class="form-control form-round" type="text" name="phone" id="phone"
                                                        :class="{ 'is-invalid': errors.phone }" v-model="form.phone">
                                                    <div class="invalid-feedback">{{ errors.phone }}</div>
                                                </div>


                                                <div class="mb-3">
                                                    <label class="required" for="address"><?php echo e(__('Address')); ?></label>
                                                    <textarea name="address" id="address" cols="30" rows="4" class="form-control" v-model="form.address" :class="{ 'is-invalid': errors.address }"></textarea>
                                                    <div class="invalid-feedback">{{ errors.name }}</div>
                                                </div>

                                                <div class="mb-3">
                                                    <label class="required" for="state"><?php echo e(__('State')); ?></label>
                                                    <select name="state" id="state" class="form-select form-round" :class="{ 'is-invalid': errors.state }" v-model="form.state" @change="fetchCounties">
                                                        <option value=""><?php echo e(__("Select State")); ?></option>
                                                        <?php $__currentLoopData = \App\Models\State::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <div class="invalid-feedback">{{ errors.state }}</div>
                                                </div>

                                                <div class="mb-3">
                                                    <label class="required" for="county"><?php echo e(__('County')); ?></label>
                                                    <select name="county" id="county" class="form-select form-round" :class="{ 'is-invalid': errors.county }" v-model="form.county">
                                                        <option value=""><?php echo e(__("Select County")); ?></option>
                                                        <option v-for="county in counties" :value="county.id">{{ county.name }}</option>
                                                    </select>
                                                    <div class="invalid-feedback">{{ errors.state }}</div>
                                                </div>

                                                <div class="mb-3">
                                                    <label class="required" for="zip_code"><?php echo e(__('Zip Code')); ?></label>
                                                    <input class="form-control form-round" type="text" name="zip_code" id="zip_code"
                                                        :class="{ 'is-invalid': errors.zip_code }" v-model="form.zip_code">
                                                    <div class="invalid-feedback">{{ errors.zip_code }}</div>
                                                </div>



                                                <div v-if="form.user_type != 'tradesmen'">
                                                    <div class="mb-3">
                                                        <label class="" for="business_description"><?php echo e(__('Business Description')); ?></label>
                                                        <textarea name="business_description" id="business_description" cols="30" rows="4" class="form-control" v-model="form.business_description" :class="{ 'is-invalid': errors.business_description }"></textarea>
                                                        <div class="invalid-feedback">{{ errors.name }}</div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="" for="company_mission"><?php echo e(__('Company Mission')); ?></label>
                                                        <input class="form-control form-round" type="text" name="company_mission" id="company_mission"
                                                            :class="{ 'is-invalid': errors.company_mission }" v-model="form.company_mission">
                                                        <div class="invalid-feedback">{{ errors.company_mission }}</div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="" for="company_vision"><?php echo e(__('Company Vision')); ?></label>
                                                        <input class="form-control form-round" type="text" name="company_vision" id="company_vision"
                                                            :class="{ 'is-invalid': errors.company_vision }" v-model="form.company_vision">
                                                        <div class="invalid-feedback">{{ errors.company_vision }}</div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="" for="products"><?php echo e(__('Products')); ?></label>
                                                        <textarea name="products" id="products" cols="30" rows="4" class="form-control" v-model="form.products" :class="{ 'is-invalid': errors.products }"></textarea>
                                                        <div class="invalid-feedback">{{ errors.products }}</div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="" for="services"><?php echo e(__('Services')); ?></label>
                                                        <textarea name="services" id="services" cols="30" rows="4" class="form-control" v-model="form.services" :class="{ 'is-invalid': errors.services }"></textarea>
                                                        <div class="invalid-feedback">{{ errors.services }}</div>
                                                    </div>
                                                </div>


                                                <div v-else>
                                                    <div class="mb-3">
                                                        <label class="" for="years_of_experience"><?php echo e(__('Years of Experience')); ?></label>
                                                        <input class="form-control form-round" type="text" name="years_of_experience" id="years_of_experience"
                                                            :class="{ 'is-invalid': errors.years_of_experience }" v-model="form.years_of_experience">
                                                        <div class="invalid-feedback">{{ errors.years_of_experience }}</div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="" for="education"><?php echo e(__('Education')); ?></label>
                                                        <input class="form-control form-round" type="text" name="education" id="education"
                                                            :class="{ 'is-invalid': errors.education }" v-model="form.education">
                                                        <div class="invalid-feedback">{{ errors.education }}</div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="" for="institution"><?php echo e(__('Institution')); ?></label>
                                                        <input class="form-control form-round" type="text" name="institution" id="institution"
                                                            :class="{ 'is-invalid': errors.institution }" v-model="form.institution">
                                                        <div class="invalid-feedback">{{ errors.institution }}</div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="" for="work_history"><?php echo e(__('Work History')); ?></label>
                                                        <input class="form-control form-round" type="text" name="work_history" id="work_history"
                                                            :class="{ 'is-invalid': errors.work_history }" v-model="form.work_history">
                                                        <div class="invalid-feedback">{{ errors.work_history }}</div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="" for="license"><?php echo e(__('License')); ?></label>
                                                        <input class="form-control form-round" type="text" name="license" id="license"
                                                            :class="{ 'is-invalid': errors.license }" v-model="form.license">
                                                        <div class="invalid-feedback">{{ errors.license }}</div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="" for="certificates"><?php echo e(__('Certificates')); ?></label>
                                                        <input class="form-control form-round" type="text" name="certificates" id="certificates"
                                                            :class="{ 'is-invalid': errors.certificates }" v-model="form.certificates">
                                                        <div class="invalid-feedback">{{ errors.certificates }}</div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="" for="achievements"><?php echo e(__('Achievements')); ?></label>
                                                        <input class="form-control form-round" type="text" name="achievements" id="achievements"
                                                            :class="{ 'is-invalid': errors.achievements }" v-model="form.achievements">
                                                        <div class="invalid-feedback">{{ errors.achievements }}</div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <label class="" for="ability_skills"><?php echo e(__('Ability Skills')); ?></label>
                                                        <input class="form-control form-round" type="text" name="ability_skills" id="ability_skills"
                                                            :class="{ 'is-invalid': errors.ability_skills }" v-model="form.ability_skills">
                                                        <div class="invalid-feedback">{{ errors.ability_skills }}</div>
                                                    </div>


                                                    <div class="mb-3">
                                                        <label class="" for="about_you"><?php echo e(__('Tell the Industry about you')); ?></label>
                                                        <textarea name="about_you" id="about_you" cols="30" rows="4" class="form-control" v-model="form.about_you" :class="{ 'is-invalid': errors.about_you }"></textarea>
                                                        <div class="invalid-feedback">{{ errors.about_you }}</div>
                                                    </div>
                                                </div>

                                                <div class="text text-success mb-3" v-if="response">{{ response }}</div>

                                                <div class="mb-3 d-flex justify-content-between align-items-center">
                                                    <button type="submit" class="btn btn-primary bg-primary text-white" :disabled="registering">
                                                        <i v-if="registering" class="fas fa-spinner fa-spin"></i>
                                                        <span><?php echo e(__('Update Profile')); ?></span>
                                                    </button>
                                                    
                                                </div>

                                            </form>



                                        </div>
                                        <!-- .profile -->
                                    </div>
                                    <!-- #item-body -->
                                </div>
                                <!-- // .bp-wrap -->
                            </div>
                            <!-- #buddypress -->
                        </div>
                        <!-- .entry-content -->

                        <footer class="entry-footer"></footer>
                        <!-- .entry-footer -->
                    </article>
                    <!-- #post-0 -->
                </div>
                <!-- #.content-inner -->
            </main>
            <!-- #main -->
        </div>



    </div><!-- #.tophive-container -->
<?php $__env->stopSection(); ?>





<?php $__env->startPush('body_scripts'); ?>
    <script>
        vdata = {
            ...vdata,
            counties: <?php echo json_encode($counties, 15, 512) ?>,
            form: {
                state: <?php echo json_encode($user->state_id, 15, 512) ?>,
                county: <?php echo json_encode($user->county_id, 15, 512) ?>,
                user_type: <?php echo json_encode($user->user_type, 15, 512) ?>,
                name: <?php echo json_encode($user->name, 15, 512) ?>,
                email: <?php echo json_encode($user->email, 15, 512) ?>,
                phone: <?php echo json_encode($user->phone, 15, 512) ?>,
                address: <?php echo json_encode($user->address, 15, 512) ?>,
                zip_code: <?php echo json_encode($user->zip_code, 15, 512) ?>,
                business_description: <?php echo json_encode($user->business_description, 15, 512) ?>,
                company_mission: <?php echo json_encode($user->company_mission, 15, 512) ?>,
                company_vision: <?php echo json_encode($user->company_vision, 15, 512) ?>,
                products: <?php echo json_encode($user->products, 15, 512) ?>,
                services: <?php echo json_encode($user->services, 15, 512) ?>,

                trade: <?php echo json_encode($user->trade_id, 15, 512) ?>,
                profession_title: <?php echo json_encode($user->profession_title, 15, 512) ?>,
                years_of_experience: <?php echo json_encode($user->years_of_experience, 15, 512) ?>,
                education: <?php echo json_encode($user->education, 15, 512) ?>,
                institution: <?php echo json_encode($user->institution, 15, 512) ?>,
                work_history: <?php echo json_encode($user->work_history, 15, 512) ?>,
                license: <?php echo json_encode($user->license, 15, 512) ?>,
                certificates: <?php echo json_encode($user->certificates, 15, 512) ?>,
                achievements: <?php echo json_encode($user->achievements, 15, 512) ?>,
                ability_skills: <?php echo json_encode($user->ability_skills, 15, 512) ?>,
                about_you: <?php echo json_encode($user->about_you, 15, 512) ?>
            },
            errors: {},
            registering: false,
            response: null
        }

        vmethods = {
            ...vmethods,
            async submitForm() {

                try {

                    this.registering = true;
                    this.errors = {};
                    this.response = "";
                    const res = await axios.post("<?php echo e(route('api.profile.update')); ?>", this.form);
                    this.response = res.data.message;
                    this.registering = false;
                    toastr.success("Updated Successfully");


                } catch (e) {

                    if (e.response && e.response.status == 422) {
                        for (const [key, value] of Object.entries(e.response.data.errors)) {
                            this.errors[key] = value[0];
                        }
                    } else {
                        toastr.error("Something Wen't Wrong!");
                    }

                    this.registering = false;

                }

            },
            async fetchCounties(e) {

                try {

                    const state = e.target.value;
                    const res = await axios.get("<?php echo e(route('api.counties')); ?>?state="+state);
                    this.counties = res.data.data;

                } catch (e) {

                    if (e.response && e.response.status == 422) {
                        for (const [key, value] of Object.entries(e.response.data.errors)) {
                            this.errors[key] = value[0];
                        }
                    } else {
                        toastr.error("Something Wen't Wrong!");
                    }

                    this.registering = false;

                }

            }
        }

        vcreated = {
            ...vcreated,

            // function key: function(){}
        }

        vmounted = {
            ...vmounted,
            // function key: function(){}
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\resources\views/user/profile-edit.blade.php ENDPATH**/ ?>