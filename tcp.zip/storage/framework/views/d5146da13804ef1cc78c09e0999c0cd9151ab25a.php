<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="<?php echo e(session('lang_dir')); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->yieldContent('meta_tags'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.scrollbar.css')); ?>">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet" />

    <?php echo $__env->yieldPushContent('head_tags'); ?>

    <?php if(session('lang_dir') == 'rtl'): ?>
        <style>
            @media (min-width: 768px){
                #main-sidebar{
                    right: 0;
                }

                #top-header, #main-content{
                    margin-right: 250px;
                    margin-left: 0;
                }
            }
        </style>
    <?php endif; ?>
</head>

<body>

    <div id="app">
        <header class="bg-white sticky-top shadow-sm" id="top-header">
            <div class="container-fluid">
                <nav class="navbar">
                    <div>
                        <button type="button" class="btn btn-light" onclick="toggleSidebar()">
                            <i class="fas fa-bars"></i>
                        </button>
                    </div>
                    <div>
                        <ul class="nav ml-auto">

                            <li class="nav-item dropdown nav-menu">
                                <a class="nav-link btn border mx-3 btn-sm rounded-pill" target="_blank" href="<?php echo e(url('/')); ?>"><?php echo e(__("Visit Website")); ?></a>
                            </li>


                            <?php if (isset($component)) { $__componentOriginal5be4822e7f29032d85db4a0aace293fe16f2a141 = $component; } ?>
<?php $component = SalimHosen\Core\View\Components\Notification::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('core-notification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(SalimHosen\Core\View\Components\Notification::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5be4822e7f29032d85db4a0aace293fe16f2a141)): ?>
<?php $component = $__componentOriginal5be4822e7f29032d85db4a0aace293fe16f2a141; ?>
<?php unset($__componentOriginal5be4822e7f29032d85db4a0aace293fe16f2a141); ?>
<?php endif; ?>

                            <li class="nav-item dropdown nav-menu">
                                <a class="nav-link p-0" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown"
                                   aria-expanded="false">
                                    <span class="avatar avatar-sm rounded-circle">
                                        <img alt="Image placeholder" class="img-fluid"
                                             src="<?php echo e(asset(Auth::check() && Auth::user()->avatar ? 'images/user/' . Auth::user()->avatar : 'images/avatar.png')); ?>"
                                             width="40" height="40">
                                    </span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuLink">
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">
                                            <i class="far fa-user"></i>
                                            <span class="mx-1"></span>
                                            <?php echo e(__('Profile')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                            <i class="fas fa-sign-out-alt">

                                            </i>
                                            <span class="mx-1"></span>
                                            <?php echo e(__('Logout')); ?>

                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </header>
        <main>
            <aside id="main-sidebar">
                <?php
                    $currentRoute = request()
                        ->route()
                        ->getName();
                ?>
                <div class="scrollbar-inner">
                    <div class="text-center p-2">
                        <h2>
                            <a href="" class="text-white">
                                
                                     <h4 class="text-white">TCP</h4>
                            </a>
                        </h2>
                        <hr>
                    </div>
                    <div class="hr-line"></div>
                    <ul class="nav flex-column px-2">

                        <li class="nav-item px-3 nav-category-divider text-white mb-2"><?php echo e(__('MAIN')); ?></li>

                        <li class="nav-item">
                            <a class="nav-link text-white" href="<?php echo e(route('home')); ?>" id="home-menu">
                                <i class="fas fa-fw fa-tachometer-alt"></i>
                                <span><?php echo e(__('Dashboard')); ?></span>
                            </a>
                        </li>

                        


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['access_permission', 'access_role', 'access_subrole', 'access_user'])): ?>
                            <li class="nav-item">
                                <a class="nav-link text-white" data-bs-toggle="collapse" href="#collapseUserManagement" role="button"
                                   aria-expanded="false" aria-controls="collapseUserManagement">
                                    <i class="fas fa-users"></i>
                                    <span><?php echo e(__('User Management')); ?></span>
                                </a>

                                <ul class="list-group collapse" id="collapseUserManagement">

                                    <li class="nav-item">
                                        <a class="nav-link text-white" href="<?php echo e(route('permissions.index')); ?>" id="permissions-menu">
                                            <i class="fas fa-circle invisible"></i>
                                            <span><?php echo e(__('Permissions')); ?></span>
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link text-white" href="<?php echo e(route('roles.index')); ?>" id="roles-menu">
                                            <i class="fas fa-circle invisible"></i>
                                            <span><?php echo e(__('Roles')); ?></span>
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link text-white" href="<?php echo e(route('subroles.index')); ?>" id="subroles-menu">
                                            <i class="fas fa-circle invisible"></i>
                                            <span><?php echo e(__('Sub Roles')); ?></span>
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link text-white" href="<?php echo e(route('users.index')); ?>" id="users-menu">
                                            <i class="fas fa-circle invisible"></i>
                                            <span><?php echo e(__('All Users')); ?></span>
                                        </a>
                                    </li>

                                </ul>
                            </li>
                        <?php endif; ?>

                        <?php if ($__env->exists("menu")) echo $__env->make("menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php if ($__env->exists("website::menu")) echo $__env->make("website::menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage_setting'])): ?>
                            <li class="nav-item">
                                <a class="nav-link text-white" data-bs-toggle="collapse" href="#collapseSettings" role="button"
                                   aria-expanded="false" aria-controls="collapseExample">
                                    <i class="fas fa-cogs"></i>
                                    <span><?php echo e(__('Settings')); ?></span>
                                </a>
                                <ul class="list-group collapse" id="collapseSettings">
                                    <li class="nav-item">
                                        <a class="nav-link text-white" href="<?php echo e(route('settings.general')); ?>" id="settings-menu">
                                            <i class="fas fa-circle invisible"></i>
                                            <span><?php echo e(__('General Settings')); ?></span>
                                        </a>
                                    </li>


                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </aside>
            <section id="main-content">
                <div class="container-fluid my-3">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </section>
        </main>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
    <script src="<?php echo e(asset('js/jquery.scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script>
        $(document).ready(function() {

            const route = <?php echo json_encode(request()->route()->getName(), 15, 512) ?>.split(".")[0];
            $(`#${route}-menu`).addClass("active");
            $(`#${route}-menu`).parent().parent().addClass("show");
            $(`#${route}-menu`).parent().parent().prev().attr("aria-expanded", true);
        });
    </script>

    <?php echo $__env->make('core::partials.toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <script>
        let vdata = {};
        let vcreated = {};
        let vmounted = {};
        let vmethods = {};
        let vdestroyed = {};
    </script>

    <?php echo $__env->yieldPushContent('body_scripts'); ?>


    
    
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

    <script type="text/javascript">
        const app = new Vue({
            el: '#app',
            data: vdata,
            created() {
                Object.keys(vcreated).forEach(method => {
                    vcreated[method]();
                });
            },
            mounted() {
                Object.keys(vmounted).forEach(method => {
                    vmounted[method]();
                });
            },
            destroyed() {
                Object.keys(vdestroyed).forEach(method => {
                    vdestroyed[method]();
                });
            },
            methods: {
                ...vmethods,
            },
        });
    </script>
    

</body>

</html>
<?php /**PATH C:\xampp\htdocs\tcp\packages\salim-hosen\Core\src\Providers/../../resources/views/layouts/admin.blade.php ENDPATH**/ ?>