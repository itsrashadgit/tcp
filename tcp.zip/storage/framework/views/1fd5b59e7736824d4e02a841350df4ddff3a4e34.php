<?php $__env->startSection("content"); ?>

<!-- Content Main -->
<section class="position-relative py-1 bg-white">
    <div class="container-fluid position-relative zindex-5 py-1 py-md-2 py-lg-2">
        <div class="row justify-content-center">
            <div class="col-lg-3 col-md-3">
                <?php $states = DB::select('select * from states'); //return view('stud_view',['states'=>$states]); ?>
                <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="list-group" data-testid="state-list">
                    <li class="list-group-item list-group-item-action state-id-<?php echo e($state->id); ?>" value="<?php echo e($state->code); ?>" >
                        <a class="btn btn-default" href="<?php echo e(strtolower($state->code)); ?>"><?php echo e($state->name); ?></a>
                    </li>
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-lg-9 col-md-9 ps-md-0">
                
                <div class="tabs7">
                    <ul class="nav m-0">
                        <li class="nav-item"><a class="nav-link bg-white" style="font-size: 14px; padding: 10px 12px" href="<?php echo e(route('trade.list')); ?>">Tradesmen</a></li>
                        <li class="nav-item"><a class="nav-link bg-white" style="font-size: 14px; padding: 10px 12px" href="<?php echo e(route('trade.list')); ?>">Contractors</a></li>
                        <li class="nav-item"><a class="nav-link bg-white" style="font-size: 14px; padding: 10px 12px" href="<?php echo e(route('profile.list')); ?>">Architects/Engineers</a></li>
                        <li class="nav-item"><a class="nav-link bg-white" style="font-size: 14px; padding: 10px 12px" href="<?php echo e(route('profile.list')); ?>">Organizations/Associations</a></li>
                        <li class="nav-item"><a class="nav-link bg-white" style="font-size: 14px; padding: 10px 12px" href="<?php echo e(route('profile.list')); ?>">Schools/Education</a></li>
                        <li class="nav-item"><a class="nav-link bg-white" style="font-size: 14px; padding: 10px 12px" href="<?php echo e(route('profile.list')); ?>">Facility/Property Mgmt</a></li>
                        <li class="nav-item"><a class="nav-link bg-white" style="font-size: 14px; padding: 10px 12px" href="<?php echo e(route('profile.list')); ?>">Vendors</a></li>
                    </ul>
                </div>

                <?php if(count($counties) > 0): ?>
                    <div class="usamap">
                        <img src="<?php echo e(asset('assets/img/states/new-jersey.jpg')); ?>" usemap="#newjersey" class="mx-auto d-block" alt="united-state-map" style="width: 1200px; max-width: 100%; height: auto;" alt="new-jersey" />
                        <map name="newjersey">
                            <?php $__currentLoopData = $counties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $county): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <area target="" alt="<?php echo e($county->slug); ?>" title="<?php echo e($county->name); ?>" href="<?php echo e(route('feeds', ['state' => strtolower($county->state->code), 'county' => $county->slug])); ?>" coords="<?php echo e($county->coords); ?>" shape="<?php echo e($county->shape); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </map>
                    </div>
                <?php else: ?>
                    <img src="<?php echo e(asset("images/under-construction.png")); ?>" alt="">
                <?php endif; ?>

            </div>
        </div>

        <!-- BG shape -->
        <div class="position-absolute end-0 bottom-0 text-primary">
            <svg width="469" height="343" viewBox="0 0 469 343" fill="none" xmlns="http://www.w3.org/2000/svg"><path opacity="0.08" fill-rule="evenodd" clip-rule="evenodd" d="M273.631 680.872C442.436 768.853 639.315 708.216 717.593 558.212C795.871 408.208 732.941 212.157 564.137 124.176C395.333 36.195 198.453 96.8326 120.175 246.836C41.8972 396.84 104.827 592.891 273.631 680.872ZM236.335 752.344C440.804 858.914 688.289 788.686 789.109 595.486C889.928 402.286 805.903 159.274 601.433 52.7043C396.964 -53.8654 149.479 16.3623 48.6595 209.562C-52.1598 402.762 31.8652 645.774 236.335 752.344Z" fill="currentColor"/><path opacity="0.08" fill-rule="evenodd" clip-rule="evenodd" d="M298.401 633.404C434.98 704.59 598.31 656.971 664.332 530.451C730.355 403.932 675.946 242.827 539.367 171.642C402.787 100.457 239.458 148.076 173.435 274.595C107.413 401.114 161.822 562.219 298.401 633.404ZM288.455 652.464C434.545 728.606 611.369 678.429 683.403 540.391C755.437 402.353 695.402 228.725 549.312 152.583C403.222 76.4404 226.398 126.617 154.365 264.655C82.331 402.693 142.365 576.321 288.455 652.464Z" fill="currentColor"/></svg>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\resources\views/state-county.blade.php ENDPATH**/ ?>