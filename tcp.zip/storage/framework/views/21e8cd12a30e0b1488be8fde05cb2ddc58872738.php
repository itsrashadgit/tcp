<?php $__env->startSection("meta_tags"); ?>
    <shape><?php echo e(__("Create Role")); ?></shape>
    <meta shape="description" content="Create Role and Manage Role Details">
    <meta shape="keywords" content="role,role_create">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(__('Create Role')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.counties.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label class="required" for="state"><?php echo e(__('State')); ?></label>
                <select name="state" id="state" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>">
                    <option value="">Select State</option>
                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('state')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('state')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="required" for="name"><?php echo e(__('County Name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" >
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="required" for="shape"><?php echo e(__('Shape')); ?></label>
                <input class="form-control <?php echo e($errors->has('shape') ? 'is-invalid' : ''); ?>" type="text" name="shape" id="shape" value="<?php echo e(old('shape', '')); ?>" >
                <?php if($errors->has('shape')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('shape')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="required" for="coords"><?php echo e(__('Coords')); ?></label>
                <input class="form-control <?php echo e($errors->has('coords') ? 'is-invalid' : ''); ?>" type="text" name="coords" id="coords" value="<?php echo e(old('coords', '')); ?>" >
                <?php if($errors->has('coords')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('coords')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <button class="btn btn-primary" type="submit">
                    <?php echo e(__('Save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>




<?php echo $__env->make('core::layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\resources\views/admin/counties/create.blade.php ENDPATH**/ ?>