<?php $__env->startSection("meta_tags"); ?>
    <shape><?php echo e(__("Create Role")); ?></shape>
    <meta shape="description" content="Create Role and Manage Role Details">
    <meta shape="keywords" content="role,role_create">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(__('Create Role')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.cities.update", $city->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>

            <div class="mb-3">
                <label class="required" for="city"><?php echo e(__('City')); ?></label>
                <input class="form-control <?php echo e($errors->has('city') ? 'is-invalid' : ''); ?>" type="text" name="city" id="city" value="<?php echo e(old('city', $city->city)); ?>" >
                <?php if($errors->has('city')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('city')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="required" for="county"><?php echo e(__('County')); ?></label>
                <input class="form-control <?php echo e($errors->has('county') ? 'is-invalid' : ''); ?>" type="text" name="county" id="county" value="<?php echo e(old('county', $city->county)); ?>" >
                <?php if($errors->has('county')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('county')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="required" for="shape"><?php echo e(__('Shape')); ?></label>
                <input class="form-control <?php echo e($errors->has('shape') ? 'is-invalid' : ''); ?>" type="text" name="shape" id="shape" value="<?php echo e(old('shape', $city->shape)); ?>" >
                <?php if($errors->has('shape')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('shape')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="required" for="coords"><?php echo e(__('Coords')); ?></label>
                <input class="form-control <?php echo e($errors->has('coords') ? 'is-invalid' : ''); ?>" type="text" name="coords" id="coords" value="<?php echo e(old('coords', $city->coords)); ?>" >
                <?php if($errors->has('coords')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('coords')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <button class="btn btn-primary" type="submit">
                    <?php echo e(__('Save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>




<?php echo $__env->make('core::layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\resources\views/admin/cities/edit.blade.php ENDPATH**/ ?>