<?php $__env->startSection('content'); ?>
    <div class="tophive-container">
        
        <div class="row my-4 gx-1">
            <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-2">
                    <a class="nav-link bg-white text-center m-1 text-dark rounded d-block" href="<?php echo e(route("profile.list")); ?>">
                        <div>
                            
                            <img src="<?php echo e(asset("uploads/trades/$trade->image")); ?>" alt="<?php echo e($trade->name); ?>" class="img-fluid" width="40">
                        </div>
                        <div><?php echo e($trade->name); ?></div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('body_scripts'); ?>


        <script>
            vdata = {
                ...vdata,
                loading_feeds: true,
                feeds: [],
                feedform: {
                    visibility: 'public'
                },
            }

            vmethods = {
                ...vmethods,
            }

            vcreated = {
                ...vcreated,
                run: function(){

                }
                // function key: function(){}
            }

            vmounted = {
                ...vmounted,
                // function key: function(){}
            }
        </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\resources\views/trade-list.blade.php ENDPATH**/ ?>