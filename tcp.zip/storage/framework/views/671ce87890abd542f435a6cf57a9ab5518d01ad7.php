

<?php $__env->startSection("meta_tags"); ?>
    <title><?php echo e(__("Admin Dashboard")); ?></title>
    <meta name="description" content="Create Employee and Manage Employee Details">
    <meta name="keywords" content="employee,employee_create">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="row mb-3">
    <div class="col-sm-6 col-lg-3">
       <div class="card text-white bg-primary">
            <div class="p-3">
                <div class="text-value-lg">0</div>
                <div><?php echo e(__("New Orders")); ?></div>
            </div>
            <a href="" class="d-block bg-white text-center py-1"><?php echo e(__("More Info")); ?></a>
       </div>
    </div>
    <div class="col-sm-6 col-lg-3">
       <div class="card text-white bg-info">
        <div class="p-3">
            <div class="text-value-lg">0</div>
            <div><?php echo e(__("Total Orders")); ?></div>
        </div>
        <a href="" class="d-block bg-white text-center py-1"><?php echo e(__("More Info")); ?></a>
       </div>
    </div>
    <div class="col-sm-6 col-lg-3">
       <div class="card text-white bg-warning">
        <div class="p-3">
            <div class="text-value-lg">0</div>
            <div><?php echo e(__("Total Sales")); ?></div>
        </div>
        <a href="" class="d-block bg-white text-center py-1"><?php echo e(__("More Info")); ?></a>
       </div>
    </div>
    <div class="col-sm-6 col-lg-3">
       <div class="card text-white bg-danger">
            <div class="p-3">
                <div class="text-value-lg">0</div>
                <div><?php echo e(__("New Customers")); ?></div>
            </div>
            <a href="" class="d-block bg-white text-center py-1"><?php echo e(__("More Info")); ?></a>
       </div>
    </div>
 </div>

 <div class="row">
    <div class="col-6">
        <div class="card">
            <div class="card-header"><?php echo e(__("Sale Summary")); ?></div>
            <div class="card-body">

            </div>
        </div>

    </div>
    <div class="col-6">
        <div class="card">
            <div class="card-header"><?php echo e(__("Top Selling Products")); ?></div>
            <div class="card-body">
                <table class="table table-responsive-sm">
                    <thead>
                        <tr>
                            <th><?php echo e(__("Title")); ?></th>
                            <th><?php echo e(__("Action")); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <td><?php echo e(__("Title")); ?></td>
                        <td>
                            <a href="" class="btn btn-primary btn-xs">
                                <?php echo e(__("View")); ?>

                            </a>
                        </td>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make("core::layouts.admin", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\packages\salim-hosen\Core\src\Providers/../../resources/views/home/index.blade.php ENDPATH**/ ?>