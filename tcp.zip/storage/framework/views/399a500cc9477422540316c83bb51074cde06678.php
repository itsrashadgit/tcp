

<?php $__env->startSection("meta_tags"); ?>
    <?php if (isset($component)) { $__componentOriginal18cf1a933cf140ce09d07f5fd05a84ba6966c8cb = $component; } ?>
<?php $component = SalimHosen\Website\View\Components\MetaTags::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website-meta-tags'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(SalimHosen\Website\View\Components\MetaTags::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18cf1a933cf140ce09d07f5fd05a84ba6966c8cb)): ?>
<?php $component = $__componentOriginal18cf1a933cf140ce09d07f5fd05a84ba6966c8cb; ?>
<?php unset($__componentOriginal18cf1a933cf140ce09d07f5fd05a84ba6966c8cb); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-5 mx-auto">

            <div class="card my-5 rounded border-0" v-cloak>


                <div class="card-body p-4">

                    <h5 class="mb-4 ember-bold"><?php echo e(__("Login")); ?></h5>


                    <form action="<?php echo e(route('login')); ?>" method="post" @submit.prevent="submitForm">

                        <?php echo csrf_field(); ?>

                        <div class="mb-4">
                            <label class="required" for="email"><?php echo e(__('Email')); ?></label>
                            <input class="form-control form-round" type="email" name="email" id="email"
                                :class="{ 'is-invalid': errors.email }" v-model="loginform.email" autocomplete="new-password">
                            <div class="invalid-feedback">{{ errors.email }}</div>
                        </div>

                        <div class="mb-4">
                            <label class="required" for="password"><?php echo e(__('Password')); ?></label>
                            <input class="form-control form-round" type="password" name="password" id="password"
                                autocomplete="new-password" :class="{ 'is-invalid': errors.password }"
                                v-model="loginform.password" autocomplete="new-password">
                            <div class="invalid-feedback">{{ errors.password }}</div>
                        </div>

                        




                        <div class="mb-3 d-flex justify-content-between">

                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" v-model="loginform.remember" id="remember">
                                <label class="form-check-label" for="remember">
                                    <?php echo e(__('Remember Me')); ?>

                                </label>
                            </div>

                            <a href="<?php echo e(route('password.request')); ?>"
                                class="text text-danger"><?php echo e(__('Forgot Password?')); ?></a>
                        </div>

                        <div class="text text-danger mb-3" v-show="errors.message">{{ errors.message }} <a
                            href="<?php echo e(route('verification.resend')); ?>"
                            v-show="errors.verification"><?php echo e(__('Resend Verification Link')); ?></a></div>


                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary w-100" :disabled="loading">
                                <i class="fas fa-spinner fa-spin" v-show="loading"></i>
                                <span><?php echo e(__('Login')); ?></span>
                            </button>
                        </div>

                    </form>
                    <p class="text-center"><?php echo e(__('Dont have an account')); ?>? <a href="<?php echo e(route('register')); ?>"
                            class="text text-primary font-weight-bold"><?php echo e(__('Register')); ?></a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('body_scripts'); ?>
    <script>
        vdata = {
            ...vdata,
            loginform: {
                email: '',
                password: '',
                role: "user"
            },
            errors: {},
            loading: false,
            response: null
        }

        vmethods = {
            ...vmethods,
            async submitForm() {

                try {

                    this.loading = true;
                    this.errors = {};
                    this.response = "";
                    const res = await axios.post("<?php echo e(route('login')); ?>", this.loginform);
                    window.location.reload();

                } catch (e) {

                    if (e.response && e.response.status == 422) {
                        for (const [key, value] of Object.entries(e.response.data.errors)) {
                            this.errors[key] = value[0];
                        }
                    } else {
                        toastr.error("Something Wen't Wrong!");
                    }

                    this.loading = false;

                }

            }
        }

        vcreated = {
            ...vcreated
            // function key: function(){}
        }

        vmounted = {
            ...vmounted,
            // function key: function(){}
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\resources\views/auth/login.blade.php ENDPATH**/ ?>