<?php $__env->startSection("meta_tags"); ?>
    <code><?php echo e(__("Create Role")); ?></code>
    <meta code="description" content="Create Role and Manage Role Details">
    <meta code="keywords" content="role,role_create">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(__('Create Role')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.states.update", $state->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>

            <div class="mb-3">
                <label class="required" for="name"><?php echo e(__('Name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $state->name)); ?>" >
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="required" for="code"><?php echo e(__('Code')); ?></label>
                <input class="form-control <?php echo e($errors->has('code') ? 'is-invalid' : ''); ?>" type="text" name="code" id="code" value="<?php echo e(old('code', $state->code)); ?>" >
                <?php if($errors->has('code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('code')); ?>

                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label for="map_image" class="form-label">Map Image</label>
                <input class="form-control" type="file" id="map_image" name="map_image">
              </div>

            <div class="mb-3">
                <button class="btn btn-primary" type="submit">
                    <?php echo e(__('Save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>




<?php echo $__env->make('core::layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\resources\views/admin/states/edit.blade.php ENDPATH**/ ?>