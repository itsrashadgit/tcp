<li class="nav-item">
    <a class="nav-link text-white" data-bs-toggle="collapse" href="#collapseWebsite" role="button"
      aria-expanded="false" aria-controls="collapseWebsite">
      <i class="fas fa-laptop"></i>
      <span><?php echo e(__("Website")); ?></span>
    </a>
    <ul class="list-group collapse" id="collapseWebsite">
      <li class="nav-item">
        <a class="nav-link text-white" href="<?php echo e(route("menus.index")); ?>" id="menus-menu">
          <i class="fas fa-circle invisible"></i>
          <span><?php echo e(__("Menus")); ?></span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-white" href="<?php echo e(route("pages.index")); ?>" id="pages-menu">
          <i class="fas fa-circle invisible"></i>
          <span><?php echo e(__("Pages")); ?></span>
        </a>
      </li>
    </ul>
  </li>
<?php /**PATH C:\xampp\htdocs\tcp\packages\salim-hosen\Website\src\Providers/../../resources/views/menu.blade.php ENDPATH**/ ?>