


<?php $__env->startSection("meta_tags"); ?>
<title><?php echo e(__("Role List")); ?></title>
    <meta name="description" content="Role List and Manage Role Details">
    <meta name="keywords" content="role,role_list">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header border-0">
        <?php echo e(__('Role List')); ?>

    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(__('ID')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Title')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Permissions')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($role->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($role->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($role->title ?? ''); ?>

                            </td>
                            <td>
                                <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-info"><?php echo e($item->title); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("create_role")): ?>
                                        <a class="btn btn-sm btn-primary mb-2" href="<?php echo e(route('roles.show', $role->id)); ?>">
                                            <?php echo e(__('View')); ?>

                                        </a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("edit_role")): ?>
                                        <a class="btn btn-sm btn-info mb-2" href="<?php echo e(route('roles.edit', $role->id)); ?>">
                                            <?php echo e(__('Edit')); ?>

                                        </a>
                                    <?php endif; ?>

                                    <?php if($role->role_id != 0): ?>
                                        <?php if (isset($component)) { $__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff = $component; } ?>
<?php $component = SalimHosen\Core\View\Components\DeleteDialog::resolve(['id' => $role->id,'action' => route('roles.destroy', $role->id)] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('core-delete-dialog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(SalimHosen\Core\View\Components\DeleteDialog::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff)): ?>
<?php $component = $__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff; ?>
<?php unset($__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff); ?>
<?php endif; ?>
                                    <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('core::layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\packages\salim-hosen\Core\src\Providers/../../resources/views/roles/index.blade.php ENDPATH**/ ?>