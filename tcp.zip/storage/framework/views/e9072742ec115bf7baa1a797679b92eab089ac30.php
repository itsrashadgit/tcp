<?php $__env->startSection("meta_tags"); ?>
    <?php if (isset($component)) { $__componentOriginal18cf1a933cf140ce09d07f5fd05a84ba6966c8cb = $component; } ?>
<?php $component = SalimHosen\Website\View\Components\MetaTags::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('website-meta-tags'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(SalimHosen\Website\View\Components\MetaTags::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18cf1a933cf140ce09d07f5fd05a84ba6966c8cb)): ?>
<?php $component = $__componentOriginal18cf1a933cf140ce09d07f5fd05a84ba6966c8cb; ?>
<?php unset($__componentOriginal18cf1a933cf140ce09d07f5fd05a84ba6966c8cb); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-7 mx-auto ">

            <div class="card rounded my-5 border-0" v-cloak>

                <div class="card-body p-4">

                    <h2 class="mb-4"><?php echo e(__("Interview for profile")); ?></h2>
                    <form action="<?php echo e(route('api.register')); ?>" method="post" @submit.prevent="submitForm">

                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="trade_role" class="required"><?php echo e(__('I am a')); ?></label>
                            <select name="user_type" id="user_type" class="form-control" v-model="form.user_type">
                                <option value="tradesmen">Tradesmen</option>
                                <option value="contractors">Contractors</option>
                                <option value="architexts/engineers">Architects/Engineers</option>
                                <option value="trade_organization/associations">Trade Organizations/Associations</option>
                                <option value="trade_schools/education">Trade Schools/Education</option>
                                <option value="facility/property_mgmt">Facility/Property Mgmt</option>
                                <option value="vendors">Vendors</option>
                            </select>
                            
                        </div>

                        <div class="mb-3" v-if="form.user_type != 'vendors'">
                            <label class="required" for="trade"><?php echo e(__('Trade')); ?></label>
                            <input class="form-control form-round" type="text" name="trade" id="trade"
                                :class="{ 'is-invalid': errors.trade }" v-model="form.trade">
                            <div class="invalid-feedback">{{ errors.trade }}</div>
                        </div>

                        <div class="mb-3" v-if="form.user_type != 'vendors'">
                            <label class="required" for="profession_title"><?php echo e(__('Profession Title')); ?></label>
                            <input class="form-control form-round" type="text" name="profession_title" id="profession_title"
                                :class="{ 'is-invalid': errors.profession_title }" v-model="form.profession_title">
                            <div class="invalid-feedback">{{ errors.profession_title }}</div>
                        </div>

                        <div class="mb-3">
                            <label class="required" for="name"><?php echo e(__('Name')); ?></label>
                            <input class="form-control form-round" type="text" name="name" id="name"
                                :class="{ 'is-invalid': errors.name }" v-model="form.name">
                            <div class="invalid-feedback">{{ errors.name }}</div>
                        </div>

                        <div class="mb-3">
                            <label class="required" for="address"><?php echo e(__('Address')); ?></label>
                            <textarea name="address" id="address" cols="30" rows="4" class="form-control" v-model="form.address" :class="{ 'is-invalid': errors.address }"></textarea>
                            <div class="invalid-feedback">{{ errors.name }}</div>
                        </div>

                        <div class="mb-3">
                            <label class="required" for="state"><?php echo e(__('State')); ?></label>
                            <select name="state" id="state" class="form-select form-round" :class="{ 'is-invalid': errors.state }" v-model="form.state" @change="fetchCounties">
                                <option value=""><?php echo e(__("Select State")); ?></option>
                                <?php $__currentLoopData = \App\Models\State::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="invalid-feedback">{{ errors.state }}</div>
                        </div>

                        <div class="mb-3">
                            <label class="required" for="county"><?php echo e(__('County')); ?></label>
                            <select name="county" id="county" class="form-select form-round" :class="{ 'is-invalid': errors.county }" v-model="form.county">
                                <option value=""><?php echo e(__("Select County")); ?></option>
                                <option v-for="county in counties" :value="county.id">{{ county.name }}</option>
                            </select>
                            <div class="invalid-feedback">{{ errors.state }}</div>
                        </div>

                        <div class="mb-3">
                            <label class="required" for="zip_code"><?php echo e(__('Zip Code')); ?></label>
                            <input class="form-control form-round" type="text" name="zip_code" id="zip_code"
                                :class="{ 'is-invalid': errors.zip_code }" v-model="form.zip_code">
                            <div class="invalid-feedback">{{ errors.zip_code }}</div>
                        </div>

                        <div class="mb-3">
                            <label class="required" for="email"><?php echo e(__('Email')); ?></label>
                            <input class="form-control form-round" type="email" name="email" id="email"
                                :class="{ 'is-invalid': errors.email }" v-model="form.email">
                            <div class="invalid-feedback">{{ errors.email }}</div>
                        </div>

                        <div class="mb-3">
                            <label class="required" for="phone"><?php echo e(__('Phone')); ?></label>
                            <input class="form-control form-round" type="text" name="phone" id="phone"
                                :class="{ 'is-invalid': errors.phone }" v-model="form.phone">
                            <div class="invalid-feedback">{{ errors.phone }}</div>
                        </div>

                        <div class="mb-3">
                            <label class="required" for="password"><?php echo e(__('Password')); ?></label>
                            <input class="form-control form-round " type="password" name="password" id="password"
                                autocomplete="new-password" :class="{ 'is-invalid': errors.password }"
                                v-model="form.password">
                            <div class="invalid-feedback">{{ errors.password }}</div>
                        </div>

                        <div class="mb-3">
                            <label class="required"
                                for="password_confirmation"><?php echo e(__('Password Confirmation')); ?></label>
                            <input class="form-control form-round" type="password" name="password_confirmation"
                                id="password_confirmation" :class="{ 'is-invalid': errors.password_confirmation }"
                                v-model="form.password_confirmation">
                            <div class="invalid-feedback">{{ errors.password_confirmation }}</div>
                        </div>

                        <div v-if="form.role == 'vendor'">
                            <div class="mb-3">
                                <label class="required" for="business_description"><?php echo e(__('Business Description')); ?></label>
                                <textarea name="business_description" id="business_description" cols="30" rows="4" class="form-control" v-model="form.business_description" :class="{ 'is-invalid': errors.business_description }"></textarea>
                                <div class="invalid-feedback">{{ errors.name }}</div>
                            </div>

                            <div class="mb-3">
                                <label class="required" for="company_mission"><?php echo e(__('Company Mission')); ?></label>
                                <input class="form-control form-round" type="text" name="company_mission" id="company_mission"
                                    :class="{ 'is-invalid': errors.company_mission }" v-model="form.company_mission">
                                <div class="invalid-feedback">{{ errors.company_mission }}</div>
                            </div>

                            <div class="mb-3">
                                <label class="required" for="company_vision"><?php echo e(__('Company Vision')); ?></label>
                                <input class="form-control form-round" type="text" name="company_vision" id="company_vision"
                                    :class="{ 'is-invalid': errors.company_vision }" v-model="form.company_vision">
                                <div class="invalid-feedback">{{ errors.company_vision }}</div>
                            </div>

                            <div class="mb-3">
                                <label class="required" for="products"><?php echo e(__('Products')); ?></label>
                                <textarea name="products" id="products" cols="30" rows="4" class="form-control" v-model="form.products" :class="{ 'is-invalid': errors.products }"></textarea>
                                <div class="invalid-feedback">{{ errors.products }}</div>
                            </div>

                            <div class="mb-3">
                                <label class="required" for="services"><?php echo e(__('Services')); ?></label>
                                <textarea name="services" id="services" cols="30" rows="4" class="form-control" v-model="form.services" :class="{ 'is-invalid': errors.services }"></textarea>
                                <div class="invalid-feedback">{{ errors.services }}</div>
                            </div>
                        </div>


                        <div v-else>
                            <div class="mb-3">
                                <label class="required" for="years_of_experience"><?php echo e(__('Years of Experience')); ?></label>
                                <input class="form-control form-round" type="text" name="years_of_experience" id="years_of_experience"
                                    :class="{ 'is-invalid': errors.years_of_experience }" v-model="form.years_of_experience">
                                <div class="invalid-feedback">{{ errors.years_of_experience }}</div>
                            </div>

                            <div class="mb-3">
                                <label class="required" for="education"><?php echo e(__('Education')); ?></label>
                                <input class="form-control form-round" type="text" name="education" id="education"
                                    :class="{ 'is-invalid': errors.education }" v-model="form.education">
                                <div class="invalid-feedback">{{ errors.education }}</div>
                            </div>

                            <div class="mb-3">
                                <label class="required" for="institution"><?php echo e(__('Institution')); ?></label>
                                <input class="form-control form-round" type="text" name="institution" id="institution"
                                    :class="{ 'is-invalid': errors.institution }" v-model="form.institution">
                                <div class="invalid-feedback">{{ errors.institution }}</div>
                            </div>

                            <div class="mb-3">
                                <label class="required" for="work_history"><?php echo e(__('Work History')); ?></label>
                                <input class="form-control form-round" type="text" name="work_history" id="work_history"
                                    :class="{ 'is-invalid': errors.work_history }" v-model="form.work_history">
                                <div class="invalid-feedback">{{ errors.work_history }}</div>
                            </div>

                            <div class="mb-3">
                                <label class="required" for="license"><?php echo e(__('License')); ?></label>
                                <input class="form-control form-round" type="text" name="license" id="license"
                                    :class="{ 'is-invalid': errors.license }" v-model="form.license">
                                <div class="invalid-feedback">{{ errors.license }}</div>
                            </div>

                            <div class="mb-3">
                                <label class="required" for="certificates"><?php echo e(__('Certificates')); ?></label>
                                <input class="form-control form-round" type="text" name="certificates" id="certificates"
                                    :class="{ 'is-invalid': errors.certificates }" v-model="form.certificates">
                                <div class="invalid-feedback">{{ errors.certificates }}</div>
                            </div>

                            <div class="mb-3">
                                <label class="required" for="achievements"><?php echo e(__('Achievements')); ?></label>
                                <input class="form-control form-round" type="text" name="achievements" id="achievements"
                                    :class="{ 'is-invalid': errors.achievements }" v-model="form.achievements">
                                <div class="invalid-feedback">{{ errors.achievements }}</div>
                            </div>

                            <div class="mb-3">
                                <label class="required" for="ability_skills"><?php echo e(__('Ability Skills')); ?></label>
                                <input class="form-control form-round" type="text" name="ability_skills" id="ability_skills"
                                    :class="{ 'is-invalid': errors.ability_skills }" v-model="form.ability_skills">
                                <div class="invalid-feedback">{{ errors.ability_skills }}</div>
                            </div>


                            <div class="mb-3">
                                <label class="required" for="about_you"><?php echo e(__('Tell the Industry about you')); ?></label>
                                <textarea name="about_you" id="about_you" cols="30" rows="4" class="form-control" v-model="form.about_you" :class="{ 'is-invalid': errors.about_you }"></textarea>
                                <div class="invalid-feedback">{{ errors.about_you }}</div>
                            </div>
                        </div>

                        <div class="text text-success mb-3" v-if="response">{{ response }}</div>

                        <div class="mb-3 d-flex justify-content-between align-items-center">
                            <button type="submit" class="btn btn-primary" :disabled="registering">
                                <i v-if="registering" class="fas fa-spinner fa-spin"></i>
                                <span><?php echo e(__('Register')); ?></span>
                            </button>
                            <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Back to Login')); ?></a>
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('body_scripts'); ?>
    <script>
        vdata = {
            ...vdata,
            counties: [],
            form: {
                state: '',
                county: '',
                user_type: 'tradesmen',
                role: "user",
                name: '',
                email: '',
                phone: '',
                password: '',
                password_confirmation: '',
                address: '',
                zip_code: '',
                business_description: '',
                company_mission: '',
                company_vision: '',
                products: '',
                services: '',

                trade: '',
                profession_title: '',
                years_of_experience: '',
                education: '',
                institution: '',
                work_history: '',
                license: '',
                certificates: '',
                achievements: '',
                ability_skills: '',
                about_you: ''
            },
            errors: {},
            registering: false,
            response: null
        }

        vmethods = {
            ...vmethods,
            async submitForm() {

                try {

                    this.registering = true;
                    this.errors = {};
                    this.response = "";
                    const res = await axios.post("<?php echo e(route('api.register')); ?>", this.form);
                    this.response = res.data.message;
                    this.registering = false;
                    toastr.success("Registration Successful!");

                } catch (e) {

                    if (e.response && e.response.status == 422) {
                        for (const [key, value] of Object.entries(e.response.data.errors)) {
                            this.errors[key] = value[0];
                        }
                    } else {
                        toastr.error("Something Wen't Wrong!");
                    }

                    this.registering = false;

                }

            },
            async fetchCounties(e) {

                try {

                    const state = e.target.value;
                    const res = await axios.get("<?php echo e(route('api.counties')); ?>?state="+state);
                    this.counties = res.data.data;

                } catch (e) {

                    if (e.response && e.response.status == 422) {
                        for (const [key, value] of Object.entries(e.response.data.errors)) {
                            this.errors[key] = value[0];
                        }
                    } else {
                        toastr.error("Something Wen't Wrong!");
                    }

                    this.registering = false;

                }

            }
        }

        vcreated = {
            ...vcreated,

            // function key: function(){}
        }

        vmounted = {
            ...vmounted,
            // function key: function(){}
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\resources\views/auth/register.blade.php ENDPATH**/ ?>