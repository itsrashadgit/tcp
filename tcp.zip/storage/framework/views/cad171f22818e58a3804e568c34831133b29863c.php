<title><?php echo e($page->title ?? config('app.name', 'Website')); ?></title>
<meta name="description" content="<?php echo e($page->description ?? ''); ?>">
<meta name="keywords" content="<?php echo e($page->keywords ?? ''); ?>">
<?php /**PATH C:\xampp\htdocs\tcp\packages\salim-hosen\Website\src\Providers/../../resources/views/components/meta-tags.blade.php ENDPATH**/ ?>