<button type="button" class="btn btn-danger btn-xs" data-bs-toggle="modal" data-bs-target="#id_<?php echo e($id); ?>">
    <?php echo e(__("Delete")); ?>

  </button>

  <div class="modal fade" id="id_<?php echo e($id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__("Delete Dialog")); ?></h5>
          <i role="button" class="fas fa-times close"   aria-label="Close" data-bs-dismiss="modal"></i>
        </div>
        <div class="modal-body">
          <?php echo e(__("Are you Sure to Delete?")); ?>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__("No")); ?></button>

            

            <form action="<?php echo e($action); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <?php echo method_field("DELETE"); ?>
                <button type="submit" class="btn btn-danger"><?php echo e(__("Yes")); ?></button>
            </form>
        </div>
      </div>
    </div>
  </div>


<?php /**PATH C:\xampp\htdocs\tcp\packages\salim-hosen\Core\src\Providers/../../resources/views/components/delete-dialog.blade.php ENDPATH**/ ?>