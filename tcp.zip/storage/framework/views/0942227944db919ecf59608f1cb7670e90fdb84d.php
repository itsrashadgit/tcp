<?php $__env->startSection("meta_tags"); ?>
<title><?php echo e(__("County List")); ?></title>
    <meta name="description" content="County List and Manage County Details">
    <meta name="keywords" content="County,County">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="mb-3">
    <a href="<?php echo e(route("admin.counties.create")); ?>" class="btn btn-primary">
        Create County
    </a>
</div>

<div class="card">
    <div class="card-header border-0">
        <?php echo e(__('County List')); ?>

    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(__('ID')); ?>

                        </th>

                        <th>
                            <?php echo e(__('County')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $counties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $county): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($county->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($county->id ?? ''); ?>

                            </td>

                            <td>
                                <?php echo e($county->name ?? ''); ?>

                            </td>

                            <td>
                                
                                <a class="btn btn-sm btn-info mb-2" href="<?php echo e(route('admin.counties.edit', $county->id)); ?>">
                                    <?php echo e(__('Edit')); ?>

                                </a>
                                
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo e($counties->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('core::layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\resources\views/admin/counties/index.blade.php ENDPATH**/ ?>