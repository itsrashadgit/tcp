<li class="nav-item">
    <a class="nav-link text-white" href="<?php echo e(route('admin.states.index')); ?>" id="home-menu">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span><?php echo e(__('States')); ?></span>
    </a>
</li>

<li class="nav-item">
    <a class="nav-link text-white" href="<?php echo e(route('admin.counties.index')); ?>" id="home-menu">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span><?php echo e(__('Counties')); ?></span>
    </a>
</li>
<?php /**PATH C:\xampp\htdocs\tcp\resources\views/menu.blade.php ENDPATH**/ ?>