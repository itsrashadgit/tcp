

<?php $__env->startSection("title", "Permission List"); ?>

<?php $__env->startSection("meta_tags"); ?>
    <meta name="description" content="Permission List and Manage Permission List Details">
    <meta name="keywords" content="permission,permission_list">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div style="margin-bottom: 10px;" class="row">
    <div class="col-lg-12">
        <a class="btn btn-success" href="<?php echo e(route('permissions.create')); ?>">
            <?php echo e(__('Create Permission')); ?>

        </a>
    </div>
</div>

<div class="card">
    <div class="card-header border-0">
        <?php echo e(__('Permission List')); ?>

    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(__('ID')); ?>

                        </th>
                        <th>
                            <?php echo e(__('Title')); ?>

                        </th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($permission->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($permission->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($permission->title ?? ''); ?>

                            </td>
                            

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('core::layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\packages\salim-hosen\Core\src\Providers/../../resources/views/permissions/index.blade.php ENDPATH**/ ?>