


<?php $__env->startSection("meta_tags"); ?>
<title><?php echo e(__("Menu List")); ?></title>
    <meta name="description" content="Menu List and Manage Menu Details">
    <meta name="keywords" content="menu,menu_list">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('menus.create')); ?>">
                <?php echo e(__("Create Menu")); ?>

            </a>
        </div>
    </div>

<div class="card">
    <div class="card-header border-0">
        <?php echo e(__("Menu List")); ?>

    </div>

    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(__("#")); ?>

                        </th>
                        <th>
                            <?php echo e(__("Name")); ?>

                        </th>
                        <th>
                            <?php echo e(__("URL")); ?>

                        </th>
                        <th>
                            <?php echo e(__("Status")); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($menu->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($menu->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($menu->name ?? ''); ?>

                            </td>
                            <td>
                                /<?php echo e($menu->url); ?>

                            </td>
                            <td>
                                <?php if($menu->is_active): ?>
                                    <span class="badge bg-primary"><?php echo e(__("Active")); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-primary"><?php echo e(__("Inactive")); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>

                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('menus.edit', $menu->id)); ?>">
                                        <?php echo e(__("Edit")); ?>

                                    </a>

                                    <?php if (isset($component)) { $__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff = $component; } ?>
<?php $component = SalimHosen\Core\View\Components\DeleteDialog::resolve(['id' => $menu->id,'action' => route('menus.destroy', $menu->id)] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('core-delete-dialog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(SalimHosen\Core\View\Components\DeleteDialog::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff)): ?>
<?php $component = $__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff; ?>
<?php unset($__componentOriginalf3d2ff18cfd623ff90de2b042c13e335a45301ff); ?>
<?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('core::layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tcp\packages\salim-hosen\Website\src\Providers/../../resources/views/menu/index.blade.php ENDPATH**/ ?>