<li class="nav-item">
    <a class="nav-link text-white" href="{{ route('admin.states.index') }}" id="home-menu">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>{{ __('States') }}</span>
    </a>
</li>

<li class="nav-item">
    <a class="nav-link text-white" href="{{ route('admin.counties.index') }}" id="home-menu">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>{{ __('Counties') }}</span>
    </a>
</li>
