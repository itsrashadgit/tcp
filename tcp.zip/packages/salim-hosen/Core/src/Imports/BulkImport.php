<?php

namespace SalimHosen\Core\Imports;

use Maatwebsite\Excel\Concerns\ToArray;

class BulkImport implements ToArray
{

    public function array(array $array){

    }

}
