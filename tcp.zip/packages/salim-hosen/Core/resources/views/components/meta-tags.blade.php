<title>{{ $page->title ?? config('app.name', 'Website') }}</title>
<meta name="description" content="{{ $page->description ?? '' }}">
<meta name="keywords" content="{{ $page->keywords ?? '' }}">
